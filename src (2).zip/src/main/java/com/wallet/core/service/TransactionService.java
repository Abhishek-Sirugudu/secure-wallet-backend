package com.wallet.core.service;

import com.wallet.core.dto.DepositRequestDto;
import com.wallet.core.dto.TransferRequestDto;
import com.wallet.core.entity.Account;
import com.wallet.core.entity.FraudFlag;
import com.wallet.core.entity.Transaction;
import com.wallet.core.enums.FraudReviewStatus;
import com.wallet.core.enums.TransactionStatus;
import com.wallet.core.enums.TransactionType;
import com.wallet.core.fraud.FraudCheckResult;
import com.wallet.core.fraud.FraudDetectionEngine;
import com.wallet.core.repository.AccountRepository;
import com.wallet.core.repository.FraudFlagRepository;
import com.wallet.core.repository.TransactionRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class TransactionService {

    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final FraudDetectionEngine fraudDetectionEngine;
    private final FraudFlagRepository fraudFlagRepository;

    @Transactional
    public String depositFunds(Account account, DepositRequestDto request) {
        // 1. Add funds to the account
        account.setBalance(account.getBalance().add(request.getAmount()));

        // 2. Record the transaction
        Transaction transaction = Transaction.builder()
                .senderAccount(account)   // Self-funded
                .receiverAccount(account) // Self-funded
                .amount(request.getAmount())
                .type(TransactionType.DEPOSIT)
                .status(TransactionStatus.SUCCESS)
                .build();

        transactionRepository.save(transaction);

        return "Successfully deposited " + request.getAmount();
    }
    @Transactional
    public String transferFunds(Account senderAccount, TransferRequestDto request){
        Account receiverAccount = accountRepository.findByAccountNumber(request.getReceiverAccountNumber())
                .orElseThrow(() -> new RuntimeException("Receiver account not found"));

        if (senderAccount.getBalance().compareTo(request.getAmount()) < 0) {
            throw new RuntimeException("Insufficient funds");
        }


        Transaction transaction = Transaction.builder()
                .senderAccount(senderAccount)
                .receiverAccount(receiverAccount)
                .amount(request.getAmount())
                .type(TransactionType.TRANSFER)
                .status(TransactionStatus.PENDING)
                .build();


        FraudCheckResult fraudResult = fraudDetectionEngine.runChecks(transaction);

        if (fraudResult.isFlagged()) {
            // FRAUD DETECTED: Hold the funds
            transaction.setStatus(TransactionStatus.FLAGGED);

            // Only debit the sender
            senderAccount.setBalance(senderAccount.getBalance().subtract(request.getAmount()));

            transactionRepository.save(transaction);

            // Create and save the flag for the Admin to review
            FraudFlag flag = FraudFlag.builder()
                    .transaction(transaction)
                    .reason(fraudResult.reason())
                    .severity(fraudResult.severity())
                    .reviewStatus(FraudReviewStatus.PENDING)
                    .build();
            fraudFlagRepository.save(flag);

            return "Transfer flagged for manual review.";
        }

        transaction.setStatus(TransactionStatus.SUCCESS);

        senderAccount.setBalance(senderAccount.getBalance().subtract(request.getAmount()));
        receiverAccount.setBalance(receiverAccount.getBalance().add(request.getAmount()));

        transactionRepository.save(transaction);

        return "Transfer successful!";
    }
}
package com.wallet.core.fraud;

public record FraudCheckResult(boolean isFlagged, String reason, String severity) {
    public static FraudCheckResult clean() {
        return new FraudCheckResult(false, null, null);
    }

    public static FraudCheckResult flagged(String reason, String severity) {
        return new FraudCheckResult(true, reason, severity);
    }
}
